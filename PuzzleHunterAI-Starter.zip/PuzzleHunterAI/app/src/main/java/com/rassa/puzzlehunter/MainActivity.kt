package com.rassa.puzzlehunter

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(32), dp(24), dp(24))
            setBackgroundColor(Color.rgb(239, 245, 255))
        }

        val title = TextView(this).apply {
            text = "PUZZLE HUNTER AI"
            textSize = 25f
            setTextColor(Color.rgb(35, 65, 145))
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "Asisten pemecah puzzle balok"
            textSize = 16f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(28))
        }
        root.addView(subtitle, matchWrap())

        val status = TextView(this).apply {
            text = "STATUS: APLIKASI BERHASIL DIPASANG"
            textSize = 14f
            setTextColor(Color.rgb(20, 120, 75))
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(18), dp(12), dp(18))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(status, matchWrap())

        val info = TextView(this).apply {
            text = "Tahap 1 selesai: kerangka APK sudah siap.\n\nTahap berikutnya adalah menambahkan izin pembacaan layar, pendeteksi papan 8×8, dan mesin pencari solusi.\n\nAplikasi tidak akan menaruh balok secara otomatis. Kamu tetap menggeser balok sendiri mengikuti petunjuk."
            textSize = 16f
            setTextColor(Color.rgb(45, 55, 75))
            setPadding(0, dp(24), 0, dp(24))
        }
        root.addView(info, matchWrap())

        val button = Button(this).apply {
            text = "TAHAP 1 — SIAP"
            isEnabled = false
        }
        root.addView(button, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(52)
        ))

        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
