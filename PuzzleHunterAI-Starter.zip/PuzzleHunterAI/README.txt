PUZZLE HUNTER AI — STARTER APK

This is the initial Android project skeleton.
Package: com.rassa.puzzlehunter
Language: Kotlin
Java/Kotlin target: 17
Gradle: 8.13 compatible

Build command after extracting this folder:
gradle -p PuzzleHunterAI assembleDebug

Expected APK:
PuzzleHunterAI/app/build/outputs/apk/debug/app-debug.apk

Stage 1 only creates the installable app shell. It does not yet read the game screen.
Next stages: MediaProjection screen capture, board/piece recognition, solver, and floating placement guide.
